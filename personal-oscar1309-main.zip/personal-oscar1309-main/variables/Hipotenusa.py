
print("Calcular la hipotenusa")
CO = int(input("Ingrese el Catetto Opuesto: "))
CA = int(input("Ingrese el Catetto Adyacente: "))




Hipotenusa = (CO**2 + CA**2)
Raiz = Hipotenusa**(1/2)
redondedo = round(Raiz)


print("La medida de la hipotenusa es: ", Hipotenusa)
print("La raiz de la medida de la hipotenusa es: ", redondedo)