

producto = input("Ingrese nombre de producto a llevar: ")
valorUnitario = int(input("Ingrese el valor unitario: "))
cantidad = int(input("Ingrese cantidad: "))



importe = (valorUnitario*cantidad)
IVA = importe * 0.16
valorTotal = importe + IVA



print("Usted compro: ", producto)
print("IVA: ", IVA )
print("Total a pagar: ", valorTotal)