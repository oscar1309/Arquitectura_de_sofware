
lado = int(input("ingrese un lado del cuadrado para calcular el area: "))



area = lado**2


print("el Area del cuadrado es: ", area)