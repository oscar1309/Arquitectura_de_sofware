

añoActual = 2023




año = int(input("Ingrese su año de nacimiento, para calcular su edad: "))


edad = añoActual - año



print("Su edad es: ", edad)
