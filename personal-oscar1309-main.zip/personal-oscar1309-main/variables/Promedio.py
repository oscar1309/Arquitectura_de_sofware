

num1 = int(input("ingrese su primer número: "))
num2 = int(input("ingrese su segundo número: "))
num3 = int(input("ingrese su tercer número: "))
num4 = int(input("ingrese su cuarto número: "))
num5 = int(input("ingrese su quinto número: "))



promedio = (num1 + num2 + num3 + num4 + num5)/5
redondeado = round(promedio)


print("El prmedio es: ", redondeado)