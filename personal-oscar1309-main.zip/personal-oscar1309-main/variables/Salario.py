

salarioDiario = float(input("Ingrese su salario Diario: "))
diasTrabajados = int(input("Ingrese días trabajados: "))


salarioTotal = salarioDiario*diasTrabajados
pension = salarioTotal*0.10
salud = salarioTotal*0.15

salarioPagar = salarioTotal - pension - salud


print("Salario total es: ", salarioTotal)
print("Descuento por pension: ", pension)
print("Descuento por salud: ", salud)
print("Salario a pagar: ", salarioPagar)