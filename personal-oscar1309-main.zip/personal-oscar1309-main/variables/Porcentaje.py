
num = 20



cantidad = int(input("Ingrese una cantidad para calcular el 20%: "))



porcentaje = (num * cantidad)/100
redondeado = round(porcentaje)


print("el 20% de", cantidad , "es" , redondeado)