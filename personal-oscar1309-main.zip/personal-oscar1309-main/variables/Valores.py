

num1 = 30
num2 = 60
num3 = 90




cantidad = int(input("Ingrese una cantidad para calcular el 30%, 60% y 90%: "))



porcentaje1 = (num1 * cantidad)/100
porcentaje2 = (num2 * cantidad)/100
porcentaje3 = (num3 * cantidad)/100



print("el 30% de", cantidad , "es" , porcentaje1)
print("el 60% de", cantidad , "es" , porcentaje2)
print("el 90% de", cantidad , "es" , porcentaje3)