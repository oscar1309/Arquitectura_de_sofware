

num = int(input("Ingrese un numero para calcular su raíz: "))



raiz = num**(1/2)
redondear = round(raiz)


print("La raíz de su número es: ", redondear)