
t = int(input("Ingrese el tiempo en segundos: "))



minutos = t/60
hora = minutos/60
minutos1 = minutos - 60


print("los", t , "segundos son: ", minutos, "minutos")
print("Los", minutos,"minutos son:", hora, "hora y", minutos1,"minutos")
