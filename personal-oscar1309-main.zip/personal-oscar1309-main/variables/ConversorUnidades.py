

d = int(input("Ingrese la distancia en metros a convertir: "))



km = (d / 1000)
cm = (d * 100)
mm = (d * 1000)



print(d, "metro es: ", km, "km")
print(d, "metro son: ", cm, "cm")
print(d, "metro son: ", mm, "mm")
