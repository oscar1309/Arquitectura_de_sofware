
num1 = int(input("Ingrese su primero numero: "))
num2 = int(input("Ingrese su segundo numero: "))
num3 = int(input("Ingrese su tecer numero: "))




multiplicacion = num1 * num2 * num3


print("La multiplicación de sus tres número es: ", multiplicacion)