

velocidad = int(input("Ingrese la velocidad en kilometros por hora: "))
tiempo = int(input("Ingrese el tiempo en hora: "))




distancia = velocidad * tiempo



print("la distancia recorrida es: ",distancia, "Km")