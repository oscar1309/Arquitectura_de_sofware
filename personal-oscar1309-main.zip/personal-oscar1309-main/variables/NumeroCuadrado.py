

num = int(input("Ingrese un numero a calcular su cuadrado: "))




cuadrado = num**2

print("su numero al cuadrado es: ",cuadrado)
